package com.example.quiz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuestionController {

    @Autowired
    private QuestionRepository repo;

    // ✅ Add question
    @PostMapping("/add")
    public String addQuestion(@RequestBody Question q) {
        repo.save(q);
        return "Question added successfully!";
    }

    // ✅ Get all questions
    @GetMapping("/all")
    public List<Question> getAll() {
        return repo.findAll();
    }

    // ✅ Check answer
    @PostMapping("/check/{id}")
    public String checkAnswer(@PathVariable Long id, @RequestParam String answer) {
        Question q = repo.findById(id).orElse(null);
        if (q == null)
            return "❌ Question not found!";
        if (q.getCorrectAnswer().equalsIgnoreCase(answer))
            return "✅ Correct Answer!";
        else
            return "❌ Wrong! Correct Answer is: " + q.getCorrectAnswer();
    }
}